SELECT product_name, COUNT(*) AS return_count
FROM kms_data
WHERE returned = 'Yes'
GROUP BY product_name
ORDER BY return_count DESC
LIMIT 5;