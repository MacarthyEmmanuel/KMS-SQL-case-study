SELECT product_category, SUM(sales) AS total_sales
FROM kms_data
GROUP BY product_category
ORDER BY total_sales DESC
LIMIT 1;