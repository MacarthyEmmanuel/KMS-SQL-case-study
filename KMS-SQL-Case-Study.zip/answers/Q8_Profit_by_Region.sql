SELECT region, SUM(profit) AS total_profit
FROM kms_data
GROUP BY region
ORDER BY total_profit DESC;