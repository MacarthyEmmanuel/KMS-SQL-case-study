SELECT COUNT(*) AS delayed_orders
FROM kms_data
WHERE ship_date > order_date;