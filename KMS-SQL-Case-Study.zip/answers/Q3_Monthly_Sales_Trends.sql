SELECT DATE_FORMAT(order_date, '%Y-%m') AS month, SUM(sales) AS monthly_sales
FROM kms_data
GROUP BY month
ORDER BY month;