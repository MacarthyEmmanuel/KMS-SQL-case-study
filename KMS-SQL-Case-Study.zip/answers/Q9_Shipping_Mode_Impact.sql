SELECT ship_mode, AVG(DATEDIFF(ship_date, order_date)) AS avg_delivery_days
FROM kms_data
GROUP BY ship_mode
ORDER BY avg_delivery_days;