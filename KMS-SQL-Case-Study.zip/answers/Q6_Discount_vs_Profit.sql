SELECT discount, AVG(profit) AS avg_profit
FROM kms_data
GROUP BY discount
ORDER BY discount;