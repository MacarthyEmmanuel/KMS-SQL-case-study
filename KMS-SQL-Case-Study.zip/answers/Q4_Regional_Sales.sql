SELECT region, SUM(sales) AS total_sales
FROM kms_data
GROUP BY region
ORDER BY total_sales DESC;