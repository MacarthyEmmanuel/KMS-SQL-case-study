SELECT product_name, product_base_margin
FROM kms_data
ORDER BY product_base_margin DESC
LIMIT 5;