SELECT customer_segment, SUM(sales) AS total_sales
FROM kms_data
GROUP BY customer_segment
ORDER BY total_sales DESC;