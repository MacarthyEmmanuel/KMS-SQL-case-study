-- (1) Highest Sales Product Category
SELECT TOP 1 Product_Category, SUM(Sales) AS Total_Sales
FROM [KMS Sql Case Study]
GROUP BY Product_Category
ORDER BY Total_Sales DESC;

-- (2) Top 3 & Bottom 3 Regions by Sales
SELECT TOP 3 Region, SUM(Sales) AS Total_Sales
FROM [KMS Sql Case Study]
GROUP BY Region
ORDER BY Total_Sales DESC;

SELECT TOP 3 Region, SUM(Sales) AS Total_Sales
FROM [KMS Sql Case Study]
GROUP BY Region
ORDER BY Total_Sales ASC;

-- (3) Total Sales of Appliances in Ontario
SELECT SUM(Sales) AS Total_Sales
FROM [KMS Sql Case Study]
WHERE Product_Category = 'Appliances' AND Region = 'Ontario';

-- (...additional queries truncated for brevity...)