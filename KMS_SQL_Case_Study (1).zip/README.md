# Kultra Mega Stores SQL Case Study 📊

## 📁 Project Overview

This case study analyzes the sales, customer behavior, shipping costs, and regional performance of Kultra Mega Stores (KMS) between 2009 and 2012. The objective is to derive actionable business insights using SQL queries.

---

## ✅ Questions, SQL Queries & Humanized Insights

### **1. Which product category had the highest sales?**

```sql
SELECT TOP 1 Product_Category, SUM(Sales) AS Total_Sales
FROM [KMS Sql Case Study]
GROUP BY Product_Category
ORDER BY Total_Sales DESC;
```

**Answer:**
- Product Category: `Technology`
- Total Sales: `5,984,248.18`

**Insights:**
- Technology leads the market in sales, showing a strong demand across all segments.
- The company should consider expanding product lines or promotions in this category.
- Investing in stock and logistics for tech items may yield higher returns.

---

### **2. What are the top 3 and bottom 3 regions by total sales?**

```sql
-- Top 3 Regions
SELECT TOP 3 Region, SUM(Sales) AS Total_Sales
FROM [KMS Sql Case Study]
GROUP BY Region
ORDER BY Total_Sales DESC;

-- Bottom 3 Regions
SELECT TOP 3 Region, SUM(Sales) AS Total_Sales
FROM [KMS Sql Case Study]
GROUP BY Region
ORDER BY Total_Sales ASC;
```

**Top 3 Regions by Sales:**
- West: 3,597,549.27
- Ontario: 3,063,212.48
- Prarie: 2,837,304.61

**Bottom 3 Regions by Sales:**
- Nunavut: 116,376.48
- Northwest Territories: 800,847.33
- Yukon: 975,867.38

**Insights:**
- Sales are strongest in the West and Ontario, suggesting saturated and loyal markets.
- The bottom regions may benefit from awareness campaigns or better logistics.
- Exploring regional preferences could help boost sales in underserved locations.

---

### **3. What were the total sales of appliances in Ontario?**

```sql
SELECT SUM(Sales) AS Total_Sales
FROM [KMS Sql Case Study]
WHERE Product_Category = 'Appliances' AND Region = 'Ontario';
```

**Answer:**
- Total Sales of Appliances in Ontario: `202,346.84`

**Insights:**
- Appliance sales in Ontario are relatively low compared to other categories.
- This may suggest a pricing issue or a lack of brand awareness in this region.
- Product placement and marketing in Ontario could be adjusted to improve results.

---

(...truncated to fit preview...)